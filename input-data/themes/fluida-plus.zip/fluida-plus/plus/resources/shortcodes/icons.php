﻿<?php
/*
* ! The icons lists are reused in multiple locations; make sure to update all when needed !
* ! Remember to sync with the arrays in options.php and in the styling file !
*/

/*** landing page blocks icons ***/
$block_icons = array(
	'no-icon' => '&nbsp;',
	'toggle' => 'e003',
	'layout' => 'e004',
	'lock' => 'e007',
	'unlock' => 'e008',
	'target' => 'e012',
	'disc' => 'e019',
	'microphone' => 'e048',
	'play' => 'e052',
	'cloud2' => 'e065',
	'cloud-upload' => 'e066',
	'cloud-download' => 'e067',
	'plus2' => 'e114',
	'minus2' => 'e115',
	'check2' => 'e116',
	'cross2' => 'e117',
	'users2' => 'e00a',
	'user' => 'e00b',
	'trophy' => 'e00c',
	'speedometer' => 'e00d',
	'screen-tablet' => 'e00f',
	'screen-smartphone' => 'e01a',
	'screen-desktop' => 'e01b',
	'plane' => 'e01c',
	'notebook' => 'e01d',
	'magic-wand' => 'e01e',
	'hourglass2' => 'e01f',
	'graduation' => 'e02a',
	'fire' => 'e02b',
	'eyeglass' => 'e02c',
	'energy' => 'e02d',
	'chemistry' => 'e02e',
	'bell' => 'e02f',
	'badge' => 'e03a',
	'speech' => 'e03b',
	'puzzle' => 'e03c',
	'printer' => 'e03d',
	'present' => 'e03e',
	'pin' => 'e03f',
	'picture2' => 'e04a',
	'map' => 'e04b',
	'layers' => 'e04c',
	'globe' => 'e04d',
	'globe2' => 'e04e',
	'folder' => 'e04f',
	'feed' => 'e05a',
	'drop' => 'e05b',
	'drawar' => 'e05c',
	'docs' => 'e05d',
	'directions' => 'e05e',
	'direction' => 'e05f',
	'cup2' => 'e06b',
	'compass' => 'e06c',
	'calculator' => 'e06d',
	'bubbles' => 'e06e',
	'briefcase' => 'e06f',
	'book-open' => 'e07a',
	'basket' => 'e07b',
	'bag' => 'e07c',
	'wrench' => 'e07f',
	'umbrella' => 'e08a',
	'tag' => 'e08c',
	'support' => 'e08d',
	'share' => 'e08e',
	'share2' => 'e08f',
	'rocket' => 'e09a',
	'question' => 'e09b',
	'pie-chart2' => 'e09c',
	'pencil2' => 'e09d',
	'note' => 'e09e',
	'music-tone-alt' => 'e09f',
	'list2' => 'e0a0',
	'like' => 'e0a1',
	'home2' => 'e0a2',
	'grid' => 'e0a3',
	'graph' => 'e0a4',
	'equalizer' => 'e0a5',
	'dislike' => 'e0a6',
	'calender' => 'e0a7',
	'bulb' => 'e0a8',
	'chart' => 'e0a9',
	'clock' => 'e0af',
	'envolope' => 'e0b1',
	'flag' => 'e0b3',
	'folder2' => 'e0b4',
	'heart2' => 'e0b5',
	'info' => 'e0b6',
	'link' => 'e0b7',
	'refresh' => 'e0bc',
	'reload' => 'e0bd',
	'settings' => 'e0be',
	'arrow-down' => 'e604',
	'arrow-left' => 'e605',
	'arrow-right' => 'e606',
	'arrow-up' => 'e607',
	'paypal' => 'e608',
	'home' => 'e800',
	'apartment' => 'e801',
	'data' => 'e80e',
	'cog' => 'e810',
	'star' => 'e814',
	'star-half' => 'e815',
	'star-empty' => 'e816',
	'paperclip' => 'e819',
	'eye2' => 'e81b',
	'license' => 'e822',
	'picture' => 'e827',
	'book' => 'e828',
	'bookmark' => 'e829',
	'users' => 'e82b',
	'store' => 'e82d',
	'calendar' => 'e836',
	'keyboard' => 'e837',
	'spell-check' => 'e838',
	'screen' => 'e839',
	'smartphone' => 'e83a',
	'tablet' => 'e83b',
	'laptop' => 'e83c',
	'laptop-phone' => 'e83d',
	'construction' => 'e841',
	'pie-chart' => 'e842',
	'gift' => 'e844',
	'diamond' => 'e845',
	'cup3' => 'e848',
	'leaf' => 'e849',
	'earth' => 'e853',
	'bullhorn' => 'e859',
	'hourglass' => 'e85f',
	'undo' => 'e860',
	'redo' => 'e861',
	'sync' => 'e862',
	'history' => 'e863',
	'download' => 'e865',
	'upload' => 'e866',
	'bug' => 'e869',
	'code' => 'e86a',
	'link2' => 'e86b',
	'unlink' => 'e86c',
	'thumbs-up' => 'e86d',
	'thumbs-down' => 'e86e',
	'magnifier' => 'e86f',
	'cross3' => 'e870',
	'menu' => 'e871',
	'list' => 'e872',
	'warning' => 'e87c',
	'question-circle' => 'e87d',
	'check' => 'e87f',
	'cross' => 'e880',
	'plus' => 'e881',
	'minus' => 'e882',
	'layers2' => 'e88e',
	'text-format' => 'e890',
	'text-size' => 'e892',
	'hand' => 'e8a5',
	'pointer-up' => 'e8a6',
	'pointer-right' => 'e8a7',
	'pointer-down' => 'e8a8',
	'pointer-left' => 'e8a9',
	'heart' => 'e930',
	'cloud' => 'e931',
	'trash' => 'e933',
	'user2' => 'e934',
	'key' => 'e935',
	'search' => 'e936',
	'settings2' => 'e937',
	'camera' => 'e938',
	'tag2' => 'e939',
	'bulb2' => 'e93a',
	'pencil' => 'e93b',
	'diamond2' => 'e93c',
	'location' => 'e93e',
	'eye' => 'e93f',
	'bubble' => 'e940',
	'stack' => 'e941',
	'cup' => 'e942',
	'phone' => 'e943',
	'news' => 'e944',
	'mail' => 'e945',
	'news2' => 'e948',
	'paperplane' => 'e949',
	'params2' => 'e94a',
	'data2' => 'e94b',
	'megaphone' => 'e94c',
	'study' => 'e94d',
	'chemistry2' => 'e94e',
	'fire2' => 'e94f',
	'paperclip2' => 'e950',
	'calendar2' => 'e951',
	'wallet' => 'e952',
);

$meta_icons = array(
	'status' => 'e81a',
	'aside' => 'e82a',
	'link' => 'e818',
	'audio' => 'e823',
	'video' => 'e829',
	'image' => 'e824',
	'gallery' => 'e825',
	'quote' => 'e80f',
	'search' => 'e816',
	'down-dir' => 'e803',
	'right-dir' => 'e806',
	'angle-left' => 'e807',
	'angle-right' => 'e808',
	'angle-up' => 'e809',
	'angle-down' => 'e80a',
	'minus' => 'e80b',
	'left-open' => 'e80c',
	'up' => 'e80e',
	'left-dir' => 'e811',
	'up-open' => 'e812',
	'ok' => 'e813',
	'cancel' => 'e814',
	'up-dir' => 'e819',
	'right-open' => 'e81e',
	'home' => 'e81f',
	'menu' => 'e820',
	'plus' => 'e821',
	'down-open' => 'e822',
	'down' => 'e826',
	'left' => 'e827',
	'right' => 'e828',
	'star-empty' => 'e82c',
	'star' => 'e82d',
	'mail' => 'e82e',
	'home-1' => 'e82f',
	'attach' => 'e830',
	'eye' => 'e831',
	'eye-off' => 'e832',
	'tags' => 'e833',
	'flag' => 'e834',
	'warning' => 'e835',
	'location' => 'e836',
	'trash' => 'e837',
	'doc' => 'e838',
	'phone' => 'e839',
	'cog' => 'e83a',
	'basket' => 'e83b',
	'basket-circled' => 'e83c',
	'wrench' => 'e83d',
	'wrench-circled' => 'e83e',
	'mic' => 'e83f',
	'volume' => 'e840',
	'volume-down' => 'e841',
	'volume-off' => 'e842',
	'headphones' => 'e843',
	'lightbulb' => 'e844',
	'resize-full' => 'e845',
	'resize-full-alt' => 'e846',
	'resize-small' => 'e847',
	'resize-vertical' => 'e848',
	'resize-horizontal' => 'e849',
	'move' => 'e84a',
	'zoom-in' => 'e84b',
	'zoom-out' => 'e84c',
	'arrows-cw' => 'e84d',
	'desktop' => 'e84e',
	'inbox' => 'e84f',
	'cloud' => 'e850',
	'book' => 'e851',
	'certificate' => 'e852',
	'tasks' => 'e853',
	'thumbs-up' => 'e854',
	'thumbs-down' => 'e855',
	'help-circled' => 'e856',
	'star-circled' => 'e857',
	'bell' => 'e858',
	'rss' => 'e859',
	'trash-circled' => 'e85a',
	'cogs' => 'e85b',
	'cog-circled' => 'e85c',
	'calendar-circled' => 'e85d',
	'mic-circled' => 'e85e',
	'volume-up' => 'e85f',
	'print' => 'e860',
	'edit-alt' => 'e861',
	'edit-2' => 'e862',
	'block' => 'e863',
);

$social_icons = array(
	'duckduckgo' => 'e801',
	'aim' => 'e802',
	'delicious' => 'e803',
	'paypal' => 'e804',
	'flattr' => 'e805',
	'android' => 'e806',
	'eventful' => 'e807',
	'smashingmagazine' => 'e808',
	'googleplus' => 'e809',
	'wikipedia' => 'e80a',
	'lanyrd' => 'e80b',
	'calendar' => 'e80c',
	'stumbleupon' => 'e80d',
	'500px' => 'e80e',
	'pinterest' => 'e80f',
	'bitcoin' => 'e810',
	'firefox' => 'e811',
	'foursquare' => 'e812',
	'chrome' => 'e813',
	'internetexplorer' => 'e814',
	'phone' => 'e815',
	'grooveshark' => 'e816',
	'99designs' => 'e817',
	'code' => 'e818',
	'digg' => 'e819',
	'spotify' => 'e81a',
	'reddit' => 'e81b',
	'about' => 'e81c',
	'codeopen' => 'e81d',
	'appstore' => 'e81e',
	'creativecommons' => 'e820',
	'dribbble' => 'e821',
	'evernote' => 'e822',
	'flickr' => 'e823',
	'link2' => 'e824',
	'viadeo' => 'e825',
	'instapaper' => 'e826',
	'weibo' => 'e827',
	'klout' => 'e828',
	'linkedin' => 'e829',
	'meetup' => 'e82a',
	'vk' => 'e82b',
	'plancast' => 'e82c',
	'disqus' => 'e82d',
	'feed' => 'e82e',
	'skype' => 'e82f',
	'twitter' => 'e830',
	'youtube' => 'e831',
	'vimeo' => 'e832',
	'windows' => 'e833',
	'xing' => 'e834',
	'yahoo' => 'e835',
	'email' => 'e837',
	'cloud' => 'e838',
	'myspace' => 'e839',
	'podcast' => 'e83a',
	'amazon' => 'e83b',
	'steam' => 'e83c',
	'link' => 'e83d',
	'dropbox' => 'e83e',
	'ebay' => 'e83f',
	'facebook' => 'e840',
	'github2' => 'e841',
	'github' => 'e842',
	'googleplay' => 'e843',
	'itunes' => 'e844',
	'plurk' => 'e845',
	'songkick' => 'e846',
	'lastfm' => 'e847',
	'gmail' => 'e848',
	'pinboard' => 'e849',
	'openid' => 'e84a',
	'quora' => 'e84b',
	'soundcloud' => 'e84c',
	'tumblr' => 'e84d',
	'wordpress' => 'e84f',
	'yelp' => 'e850',
	'intensedebate' => 'e851',
	'eventbrite' => 'e852',
	'scribd' => 'e853',
	'stripe' => 'e855',
	'opentable' => 'e856',
	'cart' => 'e857',
	'opera' => 'e858',
	'angellist' => 'e859',
	'instagram' => 'e85a',
	'dwolla' => 'e85b',
	'appnet' => 'e85c',
	'drupal' => 'e85f',
	'buffer' => 'e860',
	'pocket' => 'e861',
	'bitbucket' => 'e862',
	'phone2' => 'e863',
	'stackoverflow' => 'e865',
	'hackernews' => 'e866',
	'lkdto' => 'e867',
	'twitter2' => 'e868',
	'phone3' => 'e869',
	'mobile' => 'e86a',
	'support' => 'e86b',
	'twitch' => 'e86c',
	'beer' => 'e86d',
);
?>

<!doctype html>
<html>
<head>
    <meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
	<link rel="stylesheet" href="bootstrap.css" />
	<link rel="stylesheet" href="../admin/shortcodes.css" />
    <link rel="stylesheet" href="../../../resources/fonts/fontfaces.css" />
	<script type="text/javascript" src="jquery.js"></script>
	<script type="text/javascript" src="bootstrap.js"></script>
    <script type="text/javascript">
    $(document).ready(function() {
		prefix = '';
		if ( typeof top.cryout_shortcodes_prefix != 'undefined' ) prefix = top.cryout_shortcodes_prefix;

		current_text = top.tinymce.activeEditor.selection.getContent({format : 'text'});
		if (current_text.length<1) current_text = '';

        $('.glyphicons').on('click', 'li', function() {
            var iclass = $(this).find('.glyphicon').attr('class');
			var size = $(this).parents('body').find('#icon-size-input').val();

            top.tinymce.activeEditor.execCommand('mceInsertContent', false, '['+prefix+'icon name="' + iclass + '" size="'+ size + '"] '+current_text);
            top.tinymce.activeEditor.windowManager.close();
        });
    });
    </script>
    <style type="text/css">

    .glyphicons {
        display: block;
        overflow: hidden;
        padding-left: 0;
        list-style: none;
    }

    .glyphicons li {
        cursor: pointer;
        float: left;
        width: 12.5%;
        height: 100px;
        padding: 10px;
        margin: 0 -1px -1px 0;
        font-size: 12px;
        line-height: 1.4;
        text-align: center;
        border: 1px solid #DDD;
        word-break: break-all;
        -webkit-transition: .25s ease-out all;
        transition: .25s ease-out all;
    }

    .glyphicons li:last-child {
        margin: 0;
    }

    .glyphicons li:hover {
        background: rgba(0,0,0,.05);
    }

    .glyphicons .glyphicon {
        display: block;
        margin: 5px auto 10px;
        font-size: 24px;
    }

    h3:not(:first-child) {
        display: block;
        clear: both;
        float: none;
        margin-top: 2em;
    }

    </style>
</head>

<body>
    <div id="bs-wrapper">

		<form id="icons-form">
			<div class="form-group">
				<label for="icon-size-input">Size:</label>
				<select id="icon-size-input" class="form-control">
					<option value="xs">Smallest</option>
					<option value="sm">Small</option>
					<option value="md" selected="selected">Medium</option>
					<option value="lg">Large</option>
					<option value="xl">Larger</option>
					<option value="hb">Giant</option>
				</select>
			</div>
		</form>

        <h4> Block icons </h4>
        <ul class="glyphicons">
            <?php foreach ( $block_icons as $name => $char ) {
                echo '<li><i class="glyphicon blicon-' . $name . '"></i>' . $name . '</li>';
            } ?>
        </ul>

        <h3> Meta icons </h3>
        <ul class="glyphicons">
            <?php foreach ( $meta_icons as $name => $char ) {
                echo '<li><i class="glyphicon icon-' . $name . '"></i>' . $name . '</li>';
            } ?>
        </ul>

        <h3> Social icons </h3>
        <ul class="glyphicons">
            <?php foreach ( $social_icons as $name => $char ) {
                echo '<li><i class="glyphicon socicon-' . $name . '"></i>' . $name . '</li>';
            } ?>
        </ul>

    </div>
</body>

</html>

<?php
/**
 * Liquido
 */
function cryout_scheme_files() {
	$scheme = 'liquido'; 

	require_once( sprintf( get_template_directory() . '/plus/schemes/%s/options.php', $scheme ) );
	require_once( sprintf( get_template_directory() . '/plus/schemes/%s/custom-styles.php', $scheme ) );
} // cryout_scheme_files()
cryout_scheme_files();

function cryout_scheme_styling() {
	$scheme = 'liquido'; 
	
	wp_enqueue_style( sprintf( _CRYOUT_THEME_SLUG . '-%s', $scheme ), sprintf( get_template_directory_uri() . '/plus/schemes/%s/style.css', $scheme ), array( _CRYOUT_THEME_SLUG . '-main' ), _CRYOUT_THEME_VERSION );	
} // cryout_scheme_styling()
add_action( 'wp_enqueue_scripts', 'cryout_scheme_styling' );

function liquido_setup() {

	// Add support for flexible headers
	add_theme_support( 'custom-header', array(
		'default-image'	=> get_stylesheet_directory_uri() . '/resources/images/headers/waves.jpg',
	));

	// Default custom headers packaged with the theme.
	register_default_headers( array(
		'waves' => array(
			'url' => '%s/resources/images/headers/waves.jpg',
			'thumbnail_url' => '%s/resources/images/headers/waves.jpg',
			'description' => __( 'Waves', 'liquido' )
		),
	) );

	// Filters
	add_filter( 'fluida_custom_styles', 'liquido_custom_styles' );

} // liquido_setup()
add_action( 'after_setup_theme', 'liquido_setup' );

// FIN
<?php
/**
 * Reservoir
 */
function cryout_scheme_files() {
	$scheme = 'reservoir'; 

	require_once( sprintf( get_template_directory() . '/plus/schemes/%s/options.php', $scheme ) );
	require_once( sprintf( get_template_directory() . '/plus/schemes/%s/custom-styles.php', $scheme ) );
} // cryout_scheme_files()
cryout_scheme_files();

function cryout_scheme_styling() {
	$scheme = 'reservoir'; 
	
	wp_enqueue_style( sprintf( _CRYOUT_THEME_SLUG . '-%s', $scheme ), sprintf( get_template_directory_uri() . '/plus/schemes/%s/style.css', $scheme ), array( _CRYOUT_THEME_SLUG . '-main' ), _CRYOUT_THEME_VERSION );	
} // cryout_scheme_styling()
add_action( 'wp_enqueue_scripts', 'cryout_scheme_styling' );

function reservoir_setup() {

	// Add support for flexible headers
	add_theme_support( 'custom-header', array(
		'default-image'	=> get_stylesheet_directory_uri() . '/resources/images/headers/mountain-lake.jpg',
	));

	// Default custom headers packaged with the theme.
	register_default_headers( array(
		'mountain-lake' => array(
			'url' => '%2$s/resources/images/headers/mountain-lake.jpg',
			'thumbnail_url' => '%2$s/resources/images/headers/mountain-lake.jpg',
			'description' => __( 'Mountain Lake', 'reservoir' )
		),
	) );

	// Filters
	add_filter( 'fluida_custom_styles', 'reservoir_custom_styles' );

} // reservoir_setup()
add_action( 'after_setup_theme', 'reservoir_setup' );

// FIN
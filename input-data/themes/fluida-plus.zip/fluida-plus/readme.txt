===Fluida Plus===

Contributors: Cryout Creations
Requires at least: 4.5
Tested up to: 5.8.0
Stable tag: 1.8.7.1
Requires PHP: 5.6
License: GPLv3
License URI: http://www.gnu.org/licenses/gpl.html

== License ==

This program is free software: you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation, either version 3 of the License, or
(at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program. If not, see http://www.gnu.org/copyleft/gpl.html

Copyright 2017-2021 Cryout Creations
https://www.cryoutcreations.eu/

== Third Party Resources ==

Fluida Plus WordPress Theme bundles the following third-party resources:

HTML5Shiv, Copyright Alexander Farkas (aFarkas)
Dual licensed under the terms of the GPL v2 and MIT licenses
Source: https://github.com/aFarkas/html5shiv/

FitVids, Copyright Chris Coyier - http://css-tricks.com + Dave Rupert - http://daverupert.com
Licensed under the terms of the WTFPLlicense
Source: http://fitvidsjs.com/

Array2XML & XML2Array, Copyright Lalit Patel
Licensed under the terms of the Apache License 2.0
Source: http://www.lalit.org/lab/convert-php-array-to-xml-with-attributes

== Bundled Fonts ==

Elusive-Icons, Copyright Aristeides Stathopoulos
Licensed under the SIL Open Font License, Version 1.1
Source: http://shoestrap.org/downloads/elusive-icons-webfont/

Zocial CSS social buttons, Copyright Sam Collins
Licensed under the terms of the MIT license
Source: https://github.com/smcllns/css-social-buttons

Feather icons, Copyright Cole Bemis
Licensed under the terms of the MIT license
Source: http://colebemis.com/feather/

== Bundled Images ==

The following bundled images are released into the public domain under Creative Commons CC0:
https://unsplash.com/photos/YeH5EIRFCIs
https://pixabay.com/en/water-priroda-drops-rain-815271/
https://pixabay.com/en/jellyfish-under-water-sea-ocean-698521/
https://pixabay.com/en/waterfall-water-level-movement-335985/
https://stocksnap.io/photo/UXDUCODR2B (Liquido)

The rest of the bundled images are created by Cryout Creations and released with the theme under GPLv3


== Changelog ==

= 1.8.7.1 = 
*Release date - 30.08.2021*

* Fixed landing page portfolio sort option not working with 'random' setting
* Synchronized with Fluida 1.8.7.1:
	* Added 'fluida_box_readmore' filter for landing page featured boxes read more texts
	* Fixed shortcodes being processed twice on landing page featured boxes read more fields
	* Cleaned up remnant links to Google Plus
	* Updated to Cryout Framework 0.8.6.1:
		* Improved handling of edge cases for featured boxes category filtering with Polylang

= 1.8.7 =
*Release date - 01.07.2021*

* Synchronized with Fluida 1.8.7:
	* Added Polylang support for featured boxes categories (thanks to espasso)
	* Added 'fluida_navbelow_sameterm' filter to control previous/next post link behaviour
	* Fixed scroll-to-link functionality
	* Cleaned up frontend.js
	* Removed min-height from .main class on the landing page
	* Updated to Cryout Framework 0.8.6:
		* Improved PHP 8.0 compatibility

= 1.8.6.2 = 
*Release date - 30.03.2021*

* Synchronized with Fluida 1.8.6.2:
	* Fixed landing page animated featured boxes missing the overlay effect since 1.8.6
* Synchronized with Fluida 1.8.6.1:
	* Added workaround for incorrect alignment on centered block butons with WordPress 5.7
	* Fixed Team Members images being invisible since 1.8.6
	* Fixed landing page text areas missing background images since 1.8.6

= 1.8.6 =
*Release date - 16.03.2021*

* Added section title choice to meta hide options
* Added Jetpack portfolio post status hint
* Improved display of long titles in related posts list
* Improved breadcrumbs structure on WooCommerce sections
* Fixed label/panel shortcodes CSS overlapping WooCommerce production option labels and descriptions
* Fixed incorrect theme thumbnail displayed on theme management page when child theme is used
* Fixed Contact page template displaying the map field twice
* Synchronized with Fluida 1.8.6: 
	* Fixed "Inherit General Font" option not working as expected
	* Fixed block editor galleries layout
	* Fixed team members photos having a weird aspect ratio after Team Members plugin update
	* Fixed text indent option adding indentation to icons (including shortcodes)
	* Fixed search form overlapping mobile menu elements with small general font sizes
	* Fixed left sidebar navigation not being displayed when there are no widgets assigned
	* Fixed JS focus effects possibly breaking dynamic buttons functionality
	* Improved main navigation fallback markup
	* Renamed landing page 'static image' element to 'banner image' for clarity
	* Removed all padding/margins from before/after content and top/bottom inner widget areas
	* Added click-navigation to target panels in header content and site identity hints
	* Added configuration hint for header image when the theme's slider / banner image is active on the homepage
	* Cleaned up and optimized frontend scripts, including for WordPress 5.5/5.6 jQuery updates
	* Updated to Cryout Framework 0.8.5.7:
		* Expanded hint control styling to apply in the Site Identity panel
		* Fixed multi-font choices failing to apply correctly
		* Added echo parameters to cryout_schema_microdata() and cryout_font_select() functions
		* Improved breadcrumbs compatibility with plugins that filter section titles and add HTML markup
		* Improved JS code to remove jQuery deprecation notices since WordPress 5.6
		* Changed custom post type label in breadcrumbs from singular_name to name
		* Better cleaning of weights in font enqueues
		* Added the ability to inherit the general font on all other font control options
		* Fixed Select2 selectors no longer working with WordPress 5.6 on Firefox
		* Removed PHP and WP versions checks as these are now handled by WordPress

= 1.8.5 =
*Release date - 04.09.2020*

* Fixed Contact 2 page template meta options not being usable
* Removed unneeded margins from Inner Top / Inner Bottom widget areas 
* Synchronized with Fluida 1.8.5:
	* Fixed block editor font sizes using the incorrect 'regular' slug
	* Fixed page layout meta option not working since 1.8.4
	* Improved mobile menu color  
	* Fixed social icons sometimes overlapping mobile menu toggler on RTL
	* Additional accessibility improvements
	* Updated to Cryout Framework 0.8.5.1:
		* Even more sanitization changes to comply with wp.org requirements

= 1.8.4.1 =
*Release date - 31.05.2020*

* Integrated 'Reservoir' color scheme
* Synchronized with Fluida 1.8.4.1
	* Added 'Tested up' to and 'Requires PHP' header fields in style.css

= 1.8.4 =
*Release date - 07.05.2020*

* Synchronized with Fluida 1.8.4:
	* Added accessibility for mobile menu
	* Enabled header socials menu location by default when a social menu exists
	* Fixed plural forms in comments count for more complex languages - https://codex.wordpress.org/I18n_for_WordPress_Developers#Plurals
	* Fixed non-prefixed global variable in content.php
	* Fixed mobile menu overlapping WordPress admin bar on screens under 600px
	* Fixed logo using incorrect height after assignment in the customize preview
	* Renamed content/author-bio.php file to content/user-bio.php to avoid name colision with WordPress' templating system
	* Removed "Category page with intro" page template per TRT guidelines - https://themes.trac.wordpress.org/ticket/30509#comment:20
	* Code cleanup and sanitization improvements according to the theme sniffer rules
		* Fixed empty else statements in core.php, landing-page.php, styles.php
	* Updated to Cryout Framework 0.8.5:
		* Fixed color selector malfunction since WordPress 5.3
		* Additional sanitization

= 1.8.3 =
*Release date - 22.03.2020*

* Synchronized with Fluida 1.8.3:
	* Fixed theme layout option missing from layout panel
	* Fixed mobile menu in fixed mode causing rendering glitches in Firefox mobile with center-contained layout
	* Fixed back-to-top button hiding no longer works
	* Removed Custom CSS option as requested by the WordPress TRT team - https://themes.trac.wordpress.org/ticket/78556#comment:11 (*1)
	* Removed options save/load functionality to comply with guidelines - https://themes.trac.wordpress.org/ticket/39841#comment:27 (*2)
	
(1) Existing custom CSS is still outputed in the source of the site as a comment, to aid in the transfer to WordPress' own Additional CSS option. This will be removed completely in a future theme update.
(2) The removal of save/load functionality does not affect the Plus edition as it integrates a different version of option import/export functionality.

= 1.8.2 =
*Release date - 11.10.2019*

* Synchronized with Fluida 1.8.2:
	* Updated fixed menu styling to account for WordPress admin bar responsiveness breakpoints changes
	* Improved socials placement when mobile menu togglers is visible on larger screens
	* Fixed bullets missing on Gutenberg block and landing page text areas ordered lists
	* Fixed mobile menu toggler not following the correct height with mobile fixed menu	
	* Improved fixed mobile menu functionality to only execute when fixed menu option is enabled
	* Fixed some landing page elements missing effects on older Edge releases due to :focus-within changes in 1.8.0

= 1.8.1 = 
*Release date - 24.09.2019*

* Added support for built-in "schemes" to integrate the free edition's child themes
* Finally fixed the theme's management page missing the tabs functionality in some instances (due to general scripts being enqueued in wrong order)
* Synchronized with Fluida 1.8.1:
	* Fixed landing page status notice not being displayed when not active due to homepage setting
	* Fixed content left/right padding and top margin options missing since layout options were rearranged
	* Removed news feed from theme's about page per TRT requirements - https://themes.trac.wordpress.org/ticket/73150#comment:3
	* Hopefully fixed shaking footer on scroll on mobile Safari since 1.8.0
	* Improved list bullets styling in landing page text areas
	* Updated to Cryout Framework 0.8.4

= 1.8.0 =
*Release date - 20.08.2019*

* Added 'Full width' page template (with no sidebars and full screen width) for content builders plugins 
* Added meta option to display featured image in header or turn off header image on individual pages/posts
* Added wp_reset_postdata() in landing page portfolio section to improve compatibility with custom queries
* Fixed Cryout Tabs and Cryout Featured Posts widgets using fixed font sizes on some elements
* Fixed one wrong translation text domain
* Fixed 404 notices about missing bootstrap.css.map file
* Synchronized with Fluida 1.8.0:
	* Added 'fluida_header_image' and 'fluida_header_image_url' filters to allow custom control over featured images in header functionality
	* Added option to disable default pages navigation and improved mobile menu functionality to hide toggler when main navigation is empty
	* Added WordPress 5.2 'wp_body_open' action call
	* Added visibility on scroll functionality on the fixed menu on mobile devices
	* Improved featured boxes responsiveness on smaller screens
	* Improved icon blocks responsiveness with odd numbers
	* Improved related posts section styling
	* Improved main navigation usability on tablets by adding the option to force the mobile menu activation
	* Improved dark color schemes support for HTML select elements 
	* Improved static slider image behavior on short screens
	* Improved keyboard navigation accessibility:
		* Added 'skip to content' link
		* Added focus support for post featured images, landing page featured boxes, landing page portfolio
	* Fixed breadcrumbs links in bbPress forums/topics sections
	* Fixed line height on 'continue reading' button on hover
	* Fixed Gutenberg lists displaying bullets outside of content on landing page sections
	* Updated to Cryout Framework 0.8.3:
		* Fixed home icon missing link on WooCommerce sections
		* Optimized options migration check to reduce calls
		* (Finally?) fixed 'Too few arguments' warning in breadcrumbs on Polylang multi-lingual sites

= 1.7.0 =
*Release date - 29.05.2019*

* Added new theme layout options for specific sections: archive/category, search results, Jetpack portfolio archive, Jetpack single portfolio, WooCommerce products list, WooCommerce single product
* Added 'target' parameter for the button shortcode
* Added option for and enabled excerpts on pages
* Added GetInTouch widget
* Improved handling of base theme landing page section background colors
* Improved translations support for the Plus strings using the second textdomain with Loco Translate
* Fixed 404 notices about missing bootstrap.css.map file
* Fixed widgets administration malfunction due to unavailable wpColorPicker() call in dashboard in some instances
* Hopefully fixed the theme's management page missing the tabs functionality in some instances
* Fixed Cryout Tabs widget using wrong links on latest and popular posts
* Synchronized with Fluida 1.7.0:
	* Added option to control featured images in the header size enforcement
	* Improved Google Fonts functionality to load all weights for the general font
	* Improved footer widgets responsiveness when set to center align
	* Improved content spacing on single pages/posts when comment form is not displayed
	* Improved page/post meta options support for the block editor
	* Improved block editor styling for dark color schemes
	* Optimized layout detection code and moved to the framework
	* Optimized frontend scripts
	* Renamed top and bottom widget areas for clarity
	* Renamed and rearranged some theme options for consistency between themes
	* Fixed normalized tags still having different sizes
	* Fixed editor style option not applying to the block editor styling
	* Fixed deferring functionality applying to some dashboard scripts
	* Fixed $content_width not being defined in the dashboard
	* Multiple fixes for older IEs
	* Disabled featured images on post formats
	* Disabled search form display on the landing page when no posts are available
	* Updated Cryout Framework to 0.8.2:
		* Activated Select2 functionality on font selector controls
		* Added Select2 functionality to icon-select controls
		* Fixed RTL issues with color controls, toggle controls, half/third width selectors, number slider
		* Switched enable/disable options to use the new toggle control
		* Switched number options to use the new number slider control

= 1.6.0.2 =
*Release date - 30.12.2018*

* Synchronized with Fluida 1.6.0.2:
	* Fixed notice about malformed number format in setup.php since 1.6.0
	* Fixed Gutenberg editor background color missing
* Synchronized with Fluida 1.6.0.1:
	* Fixed block embeds responsiveness conflict with Fitvids script
	* Fixed notice about malformed number format in custom-styles.php since 1.6.0
	* Fixed classic editor styling not working since 1.6.0

= 1.6.0 =
*Release date - 19.12.2018*

* Renamed "Box Content" option to "Boxes Appearance" for clarity
* Moved individual meta options from inline styling to general body classes
* Fixed Contact widget URL handling
* Fixed undefined 'size' variable notice related to post/pages meta
* Fixed incorrect description in About widget
* Fixed typo in Featured Posts widget
* Fixed landing page posts list not using Masonry grid when general posts layout option is set to one column
* Synchronized with Fluida 1.6.0:
	* Adjusted headings color option to apply to landing page text area inner headings as well
	* Fixed WP Globus translations not working in landing page icon blocks excerpts (should improve support for other plugins as well)
	* Added 'fluida_header_crop' filter for header image crop position
	* Improved standards compliance CSS cleanup
	* Fixed long submenus sometimes causing horizontal scrollbar with non-fixed menus
	* Gutenberg editor tweaks and improvements:
		* Added styles for the new block horizontal separators
		* Added editor styles for the Gutenberg editor
		* Added support for theme colors and font sizes in the Gutenberg editor
		* Added wide image support
		* Improved list appearance in blocks
		* Fixed margins on gallery blocks
		* Fixed caption alignment in blocks
		* Fixed cover block text styling
	* Updated to Cryout Framework 0.7.8.5:
		* Improved manual excerpts detection in landing page blocks and boxes to detect <!--more--> and <!--nextpage--> tags

= 1.5.6.1 =
*Release date - 04.08.2018*

* Added new vertical align option for grid shortcodes
* Improved widget area appearance on 404/not found page
* Fixed landing page ordering control to display correct sections status
* Fixed customizer.css being enqueued two times
* Moved Plus landing page 'featured content' options to new base dedicated options section
* Renamed "Box Content" option to "Boxes Appearance" for clarity
* Updated screenshot
* Synchronized with Fluida
	v1.5.6.1
	* Updated Cryout Framework to v0.7.8.2:
		* Fixed landing page sometimes ending unexpectedly while WPML is used
	v1.5.6
	* Added landing page featured icon blocks overall disable option
	* Added support for shortcodes in custom footer text field
	* Fixed header widgets being present on the landing page when a header image is not used
	* Fixed height discrepancy between main navigation items and search icon item in some cases
	* Fixed landing page icon blocks, featured boxes and text areas WPML support
	* Fixed some animation hiccups on main navigation
	* Fixed site logo size shrinking on mobile devices
	* Fixed long site titles overlapping mobile menu placeholder
	* Fixed main navigation cannot be clicked in some cases on IE, Edge and Chrome
	* Fixed landing page content generation after first activation failing to retrieve all available static pages in some cases
	* Fixed landing page icon blocks, featured boxes, text areas background color options not working
	* Fixed slider / static slider using wrong title font after latest Serious Slider plugin update
	* Rearranged landing page 'featured content' options to dedicated options section
	* Updated Cryout Framework to v0.7.8.1:
			* Sorted icon block icons list alphabetically
			* Added required PHP version check
			* Improved required WordPress version check

= 1.5.5 =
*Release date - 09.06.2018*

* Added background size option for post/page custom background
* Added "Contact 2" page template
* Improved refresh support for Related Posts block in the customize interface
* Improved responsiveness breakpoint functionality to account for header social icons
* Changed Related Posts block to include sticky posts
* Changed landing page index and portfolio function to separate output into distinct functions
* Changed theme structure and defaults array location
* Fixed "Enter Key" button sometimes fails to work
* Fixed "Featured Posts" widget simultaneous hover on all categories
* Fixed missing date in "Featured posts", "Recent Posts" widgets when multiple posts have the same date
* Synchronized with Fluida:
	= 1.5.5 =
	* Added support for custom embedded fonts
	* Added main navigation keyboard accessibility support
	* Added mobile menu close on click/tap functionality
	* Added hints in the customizer interface for Site Identity / Header options
	* Improved mobile menu multi-line menu items behaviour
	* Increased mobile menu width on smaller devices
	* Fixed GDPR-related checkbox missing on comment form
	* Fixed comment form fields center alignment on checkboxes and radio controls
	* Fixed static slider positioning on <720px with RTL
	* Fixed site tagline positioning with RTL
	* Fixed spacing between title and logo on RTL
	* Fixed mobile menu items alignment on RTL
	* Fixed header image not visible when active on the landing page
	* Fixed header widgets being present on the landing page when the header image is not used
	* Updated to Cryout Framework 0.7.6.1

= 1.5.4.1 =
*Release date - 09.05.2018*

* Fixed Portfolio Widget missing bottom margin
* Fixed HTML validation of Google map iframe
* Fixed 'division by zero' warning when third featured boxes height option set to zero
* Fixed landing page icon blocks and featured boxes linking to unaccessible content when the featured custom post type is used and link metas are empty
* Improved landing page portfolio section spacing
* Synchronized with Fluida:
	= 1.5.4.1 =
	* Improved landing page featured boxes and text areas spacing
	* Fixed featured icon blocks container still visibile when all icon blocks are disabled
	= 1.5.4 =
	* Fixed first content title spacing spacing above rule being too broad
	* Fixed logo overlapping mobile menu placeholder when image wider than available width
	* Fixed main navigation search box not working with some color combinations

= 1.5.3.2 =
*Release date - 24.04.2018*

* Fixed landing page order control improperly displaying sections statuses
* Synchronized with Fluida:
	= 1.5.3.2 =
	* Fixed landing page text areas cannot be completely disabled
	* Fixed scroll-to-anchor functionality with Tabs/Panels
	* Improved first content title before spacing

= 1.5.3.1 =
*Release date - 18.04.2018*

* Changed widget titles to use H3 instead of H2
* Improved theme page design and made it fully responsive
* Added Polylang/WPML localization support on portfolio section options input fields
* Added hint that companion plugins require a valid licese key for installation
* Removed license key nag on WordPress multisite
* Fixed update procedure to work with renamed theme folder
* Fixed landing page section category source selector using wrong value for disabled option
* Fixed featured posts widget using full size images
* Changed Jetpack portfolio meta styling to only apply to single sections
* Changed widget areas to use <section> markup instead of lists
* Synchronized with Fluida 1.5.3.1:
	= 1.5.3.1 =
	* Reverted heading sizes apply to main content headings only
	* Added compatibility styling for Jetpack Portfolio titles sizes in widgets
	* Fixed cover+fixed background images zoomed incorrectly on Safari
	* Fixed cover+fixed background images shaky on IEs and Edge
	* Fixed q tag missing styling
	= 1.5.3 =
	* Added query resets to landing page custom queries
	* Added featured box titles link functionality
	* Improved accessibility for landing page block icons, boxes links and titles, edit button, read more links and back-to-top button
	* Improved 'scroll to anchor' functionality and extended to content and menu links
	* Changed heading sizes to apply to main content headings only
	* Fixed duplicate classname on featured image element
	* Fixed incorrect options indication in widget areas
	* Fixed featured images opacity-based animations glitch on Chrome
	* Optimized similar translations strings in theme options
	= 1.5.2.1 =
	* Re-upload of 1.5.2 due to repository issues
	= 1.5.2 =
	* Added support for WooCommerce breadcrumbs
	* Added landing page icon blocks read more links
	* Added landing page sections support for WPML/Polylang localization
	* Added missing fields to WPML/Polylang wpml-config.xml file
	* Changed example static slider image and updated screenshot to reflect this change
	* Changed search widget, landing page icon blocks, main navigation submenus appearance
	* Changed site title to use first accent color (instead of second)
	* Improved on-page SEO
	* Improved tables styling
	* Fixed HTML markup validation warning due to empty 'media' attribute
	* Fixed CSS validation warnings due to empty color fields and invalid 'default' values
	* Fixed landing page featured page section using H1 tag for title
	* Fixed landing page featured boxes not being disable-able
	* Fixed language flag images being improperly aligned in menus
	* Updated to Cryout Framework v0.7.4

= 1.5.1 =
*Release date - 04.03.2018*

* Enabled social icons below responsiveness breakpoint value
* Added third unfiltered JS field after the opening body tag
* Synchronized with Fluida:
	= 1.5.1 =
	* Fixed WooCommerce products missing styling in search results
	* Fixed quantity input being too short for double digits with WooCommerce 3.3+
	* Removed 'defer' loading of comments script due to conflict with Jetpack

= 1.5.0-beta3 =
*Release Date - 03.03.2018*

* Improved migration functionality and notification behaviour
* Added licensing functionality

= 1.5.0-beta2 =
*Release Date - 16.02.2018*

* Moved main style back to style.css
* Fixed landing page posts layout option overlapping magazine layout option (breaking image srcset sizes)
* Tweaked frontend shortcodes style and script enqueues
* Synchronized with Fluida:
	= 1.5.0.3 =
	* Fixed 'Category page with intro' template missing pagination since v1.5.0
	* Fixed landing page slider CTA buttons missing due to incomplete callback check
	* Fixed WooCommerce store and category pages using wrong title font size
	= 1.5.0.2 =
	* Improved featured images srcset functionality to support more usage cases
	* Improved compatibility of dark color schemes with Crayon Syntax Highlighter plugin's editor styling
	* Improved sublists appearance in sidebar widgets
	* Added all weight values for the typography options
	* Added missing styling for landing page featured content container
	* Fixed comment block being visible on landing page featured page
	* Updated to Cryout Framework 0.7.3
	= 1.5.0.1 =
	* Reverted theme's main style move and restored style.css to resolve a serious styles loading issues with some child themes
	* Fixed header image missing on homepage when landing page is enabled but not active
	* Moved sidebar empty checks outside of sidebar container
	* Updated to Cryout Framework 0.7.2

= 1.5.0-beta1 =
*Release Date - 19.01.2018*

* First Fluida Plus beta release, based on Fluida 1.5.0

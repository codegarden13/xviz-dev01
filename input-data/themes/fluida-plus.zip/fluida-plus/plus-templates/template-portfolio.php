<?php
/*
 * Template Name: Portfolio
 *
 * @package Cryout Plus
 */

get_header(); ?>

	<div id="container" class="<?php call_user_func( _CRYOUT_THEME_SLUG . '_get_layout_class' ); ?>">

		<main id="main" class="main">
			<?php cryout_before_content_hook(); ?>

			<?php while ( have_posts() ) : the_post(); ?>

				<article id="post-<?php the_ID(); ?>" <?php post_class(); ?>>
					<div class="schema-image">
						<?php cryout_featured_hook(); ?>
					</div>
					<div class="article-inner">
						<header>
							<?php the_title( '<h1 class="entry-title" ' . cryout_schema_microdata( 'entry-title', 0 ) . '>', '</h1>' ); ?>
							<span class="entry-meta" >
								<?php edit_post_link( __( 'Edit', 'cryout' ), '<span class="edit-link"><i class="icon-edit"></i> ', '</span>' ); ?>
							</span>
						</header>

						<?php cryout_singular_before_inner_hook();  ?>

						<div class="entry-content" <?php cryout_schema_microdata( 'text' ); ?>>
							<?php the_content(); ?>
							<?php // wp_link_pages( array( 'before' => '<div class="page-link">' . __( 'Pages:', 'cryout' ), 'after' => '</div>' ) ); ?>
						</div><!-- .entry-content -->

						<?php $project_types = get_terms ( array (
								'taxonomy' => 'jetpack-portfolio-type',
								'orderby' => 'name',
								'order' => 'ASC',
								)
							);

						if ( ! empty ( $project_types ) && ! is_wp_error( $project_types ) ) : ?>

							<nav id="portfolio-filter">
								<a href="#" class="active" data-slug="all"> <?php _e('All', 'cryout') ?></a>
								<?php foreach ($project_types as $project) { ?>
										<a href="<?php echo get_term_link($project); ?>" data-slug="<?php echo $project->slug ?>"> <?php echo $project->name ?></a>
								<?php } ?>
							</nav>

						<?php endif; ?>

						<div id="portfolio-masonry">
							<?php echo do_shortcode( '[portfolio display_types="true" display_tags="false" display_author="false" columns="3" display_content="false" ]' ); ?>
						</div>

						<?php cryout_singular_after_inner_hook();  ?>
					</div><!-- .article-inner -->
				</article><!-- #post-## -->

			<?php endwhile; ?>

			<?php cryout_after_content_hook(); ?>
		</main><!-- #main -->

		<?php call_user_func( _CRYOUT_THEME_SLUG . '_get_sidebar' ); ?>

	</div><!-- #container -->

<?php get_footer();

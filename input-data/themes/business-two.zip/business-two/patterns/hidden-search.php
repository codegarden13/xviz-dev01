<?php
/**
 * Title: Search
 * Slug: business-two/hidden-search
 * Inserter: no
 */
?>

<!-- wp:search {"label":"<?php echo esc_attr_x( 'Search', 'search form label', 'business-two' ); ?>","showLabel":false,"buttonText":"<?php echo esc_attr_x( 'Search', 'search button text', 'business-two' ); ?>","fontSize":"medium"} /-->

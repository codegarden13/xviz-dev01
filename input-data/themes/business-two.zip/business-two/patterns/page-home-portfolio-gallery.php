<?php
/**
 * Title: Portfolio home image gallery
 * Slug: business-two/page-home-gallery
 * Categories: business_two_page
 * Keywords: starter
 * Block Types: core/post-content
 * Post Types: page, wp_template
 * Viewport width: 1400
 * Description: A porfolio home page that features a gallery.
 */
?>

<!-- wp:pattern {"slug":"business-two/hidden-portfolio-hero"} /-->
<!-- wp:pattern {"slug":"business-two/gallery-offset-images-grid-4-col"} /-->
